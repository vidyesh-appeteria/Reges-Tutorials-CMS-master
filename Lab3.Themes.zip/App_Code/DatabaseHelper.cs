﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;


/// <summary>
/// Summary description for DatabaseHelper
/// </summary>
public class DatabaseHelper
{
    string connectionString;

    public DatabaseHelper()
    {
        connectionString = ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString;
    }

    /// <summary>
    /// Use for Insert/Update/Delete query
    /// </summary>
    /// <param name="cmdName">In line query or store procedure name</param>
    /// <param name="cmdType">command name or store procedure</param>
    /// <returns>number of rows affected</returns>
    public int ExecuteNonQuery(string cmdName, CommandType cmdType)
    {
        return ExecuteNonQuery(cmdName, cmdType, null);
    }

    public int ExecuteNonQuery(string cmdName, CommandType cmdType, List<SqlParameter> paras)
    {
        SqlConnection conn = null;
        SqlCommand cmd = null;
        try
        {
           
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand();

            cmd.CommandText = cmdName;
            cmd.CommandType = cmdType;
            cmd.Connection = conn;

            if (paras != null)
            {
                foreach (SqlParameter para in paras)
                {
                    cmd.Parameters.Add(para);
                }
            }
            conn.Open();
            return cmd.ExecuteNonQuery();
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            conn.Close();
            cmd = null;
        }
    }

    public DataSet FillDataSet(string cmdName, CommandType cmdType)
    {
        return FillDataSet(cmdName, cmdType, null);
    }
    public DataSet FillDataSet(string cmdName, CommandType cmdType, List<SqlParameter> paras)
    {
        SqlConnection conn = null;
        SqlCommand cmd = null;
        DataSet ds = null;

        try
        {
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand();
            ds = new DataSet();

            cmd.CommandText = cmdName;
            cmd.CommandType = cmdType;
            cmd.Connection = conn;

            if (paras != null)
            {
                foreach (SqlParameter para in paras)
                {
                    cmd.Parameters.Add(para);
                }
            }
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            da.Fill(ds);

            return ds;
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public SqlDataReader ExecuteReader(string cmdName, CommandType cmdType)
    {
        return ExecuteReader(cmdName, cmdType, null);
    }

    public SqlDataReader ExecuteReader(string cmdName, CommandType cmdType, List<SqlParameter> paras)
    {
        SqlConnection conn = null;
        SqlCommand cmd = null;

        try
        {
            conn = new SqlConnection(connectionString);
            cmd = new SqlCommand();

            cmd.CommandText = cmdName;
            cmd.CommandType = cmdType;
            cmd.Connection = conn;

            if (paras != null)
            {
                foreach (SqlParameter para in paras)
                {
                    cmd.Parameters.Add(para);
                }
            }
            conn.Open();
            return cmd.ExecuteReader(CommandBehavior.CloseConnection);
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            cmd = null;
        }
    }
}