using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.Common;

public partial class Login : System.Web.UI.Page
{

    protected void Page_PreInit(object sender, EventArgs e)
    {
        if (Session["Theme"] != null)
            this.Theme = Session["Theme"].ToString();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["Theme"] != null)
                ddlTheme.SelectedValue = Session["Theme"].ToString();
        }
    }
    protected void ddlTheme_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["Theme"] = ddlTheme.SelectedValue;
        Response.Redirect("Login.aspx");
    }



    protected void btnLogin_Click(object sender, EventArgs e)
    {
      
    }
    protected void btnSignUp_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
   
}
